# BidPilot AI — reviewed project

BidPilot is a FastAPI service with a web dashboard, PostgreSQL/SQLite storage and a separate scanner worker. It connects to each user's Freelancer account and can generate proposal drafts using Gemini/OpenAI or the local template generator. Cloud credentials are encrypted at rest; account passwords are hashed. Security depends on the deployment, secret protection and ongoing maintenance. No review can guarantee that software is free of every bug.

## Subscription behavior

| Plan ID | Price | App bid quota |
| --- | --- | --- |
| `paid_starter` | US$10 per 30 days | 150 submitted, sending or uncertain attempts in the billing period |
| `paid_pro` | US$40 per 30 days | No monthly app quota; user's hourly/daily limits and Freelancer restrictions still apply |
| `free_team` | Free | Two founder accounts maximum, including the owner |

Payment destinations are deliberately blank. Configure real destinations in `.env`. A transaction ID submitted in the dashboard is a **request for manual review**, not proof of payment. The admin must independently verify settlement in the payment provider before approval. Initial approval activates the chosen plan for 30 days. Renewing the same active tier adds 30 days to its expiry without resetting the current 30-day bid quota window; changing tiers starts a new 30-day billing period. This project does not implement Stripe webhook verification, automated recurring billing, refunds or card-data collection. A Stripe payment-link setting is only a link.

The setup utility creates the owner and optionally a second founder. Public signup cannot assign admin or free-founder privileges. Keep founder passwords private; there is no automatic email ownership verification or forgotten-password email delivery. Bootstrap password variables only create a new account; changing them later does not reset an existing account password. Plan an operator-supported identity-verification/recovery process before inviting customers.

## Ubuntu: local testing

The commands below target Ubuntu 24.04 LTS, whose default `python3` is Python 3.12. The dependency set was tested on Python 3.12. For another Ubuntu release, select a Python 3.12 interpreter explicitly or use the Docker deployment. Start on a new test installation:

```bash
sudo apt update
sudo apt install -y python3 python3-venv
cd BidPilot_AI_Team_Cloud
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements-dev.txt
python setup_local.py
python -m pytest -q
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000`. In another terminal in the project, activate `.venv` and run `python -m app.worker` when testing scanning. The web server alone does not run the background worker. Keep the development HTTP server bound to loopback; use HTTPS deployment for public traffic.

`setup_local.py` preserves an existing `.env`, generates independent random session/encryption/database secrets and creates the file with mode `0600` on Unix. It does not include any credentials supplied in a chat. Generated bootstrap passwords use `ADMIN_PASSWORD_B64`/`SECOND_FOUNDER_PASSWORD_B64` to preserve special characters across dotenv and Compose parsers; base64 is encoding, not encryption, and must be protected as the password itself. Existing plaintext `ADMIN_PASSWORD`/`SECOND_FOUNDER_PASSWORD` environment variables remain supported. Update `.env` using a private editor and keep it out of Git, screenshots and support bundles. On Windows, use `start_windows.bat` for local testing and protect `.env` with your account's file permissions.

## Ubuntu: HTTPS production deployment

A domain with DNS A/AAAA records pointing at the Ubuntu server, reachable ports 80/443 and Docker Engine with the Compose plugin are needed. Install Docker using the official instructions for your Ubuntu release. Keep SSH restricted to your access path. Do not expose PostgreSQL or port 8000 publicly.

For a fresh production installation (with Python 3.12 available):

```bash
sudo apt update
sudo apt install -y python3 python3-venv
cd BidPilot_AI_Team_Cloud
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python setup_local.py --production
chmod 600 .env
# Privately configure actual payment destinations and optional shared AI credentials.
docker compose up --build -d
docker compose ps
curl --fail https://your-domain.example/health
```

The Compose file creates a private PostgreSQL service, runs database initialization before starting web/worker, and places Caddy in front of the web service. Caddy obtains and renews TLS certificates. Only Caddy publishes ports. Application containers run as UID 10001 with a read-only root filesystem. Database and Caddy state persist in named Docker volumes. If `172.30.0.0/24` conflicts with your server networks, change both the Compose subnet/Caddy IP and `FORWARDED_ALLOW_IPS` consistently. The files are deployment configuration; the target Ubuntu host/domain still needs its own end-to-end verification.

If reusing a development `.env`, the setup command leaves it unchanged. Edit `APP_ENV=production`, `PUBLIC_URL=https://your-domain`, `SITE_DOMAIN=your-domain`, and `SECURE_COOKIES=true` privately before deploying. Compose overrides `DATABASE_URL` to its PostgreSQL instance. Use a URL-safe generated `POSTGRES_PASSWORD`; changing it in `.env` after PostgreSQL initialization does **not** change the existing database password. Never remove/recreate the database volume merely to change credentials.

Environment changes need recreation: `docker compose up -d --force-recreate web worker`. Do not run `docker compose config` in a shared terminal or paste its output; it expands secrets. Render users may use `render.yaml` as an alternative: configure shared variables once in its environment group, use the same Fernet key for web and worker, and set `PUBLIC_URL` to the actual HTTPS web URL. Hosting plans and provider prices should be checked with the host before deployment.

## API setup and live validation

1. Rotate credentials that were pasted into a chat. Use fresh keys from the intended provider and do not infer validity from a key prefix. In Settings, save personal Gemini/OpenAI credentials and run **Test AI Keys**. Server `.env` keys are a shared fallback; admin personal database keys are not shared with other users. A local template fallback can draft proposals without proving cloud API connectivity.
2. `OPENAI_BASE_URL` defaults to `https://api.openai.com/v1`. If a key belongs to an OpenAI-compatible third party, set that provider's documented HTTPS endpoint on the **server**; its privacy, billing and auth behavior need separate verification. Never send a provider key to a guessed endpoint. Set a model supported by your account.
3. Create a Freelancer sandbox token first. Connect it under **Settings → Sandbox**, confirm the imported account identity and scan projects. Token scopes, account bid balance and project eligibility remain subject to Freelancer's API.
4. Test a manual bid only on a sandbox project you control. Check it appears exactly once in Freelancer and the dashboard. A timeout creates an `uncertain` result to avoid automatic duplicate retry; reconcile against Freelancer manually.
5. To enable unattended bids, set `PLATFORM_AUTOBID_APPROVED=true`, restart web/worker, then explicitly enable Auto-Pilot in the user's Settings. Review the displayed budget, currency, project-type, daily/hourly and package limits first. Auto-chat is a separate opt-in setting. Production connections use the real Freelancer account; actual bids/messages change that account and may incur charges.
6. Before accepting a customer's payment, verify signup/login/logout, cross-user access isolation, actual provider settlement and plan expiry on your HTTPS deployment. Keep automation off for the first deployment until these checks pass.

The test suite uses controlled mocks for external APIs and does not charge cards, validate a real supplied key, or place live bids. Network/API availability on the target host, actual credentials, payment settlement and TLS/DNS must be checked there. Logs should be restricted to operators; they can include project/customer activity. Do not publish database files or operational logs.

## Backups, upgrades and recovery

Run `bash deploy/backup.sh` to create a private PostgreSQL dump. Keep encrypted off-server backups of both the dump and `.env` through a separate secure process. The dump alone cannot recover encrypted Freelancer/AI tokens without the original `FERNET_KEY`. Protect backups as customer data and define your own retention and deletion policy.

For upgrades, take a backup, test the new version and migrations against a restored copy, stop the old worker, then rebuild/redeploy. Never run two different app versions against the same live database during migration. Dependencies are pinned to versions resolved in the review environment; review advisories and rerun tests before upgrades. Docker image tags should be pinned to organization-approved image digests for controlled production releases.

Restore drill (destroys/replaces data in the selected database; first use an isolated test deployment): stop `web` and `worker`, restore a chosen dump with `docker compose exec -T db pg_restore -U bidpilot -d bidpilot --clean --if-exists < path/to/backup.dump`, restore the matching private configuration, then restart. Check login, token decryption and project history before enabling the worker.

Do not replace `FERNET_KEY` to rotate API credentials: revoke/regenerate the provider key and save the new key via Settings. Fernet key rotation requires decrypting/re-encrypting every protected field with the old/new keys and testing recovery; this project does not ship an automatic Fernet-key rotation command. Changing `SESSION_SECRET` requires a coordinated restart of all app processes and should be treated separately from revoking existing sessions. A lost encryption key means saved provider tokens must be reconnected.

## Data sent to integrations

Cloud AI requests include the profile text, name, skills, portfolio and the relevant project brief or chat message. Use of Gemini/OpenAI is subject to those providers’ privacy and billing settings. Application passwords, session cookies and Freelancer OAuth tokens are not included in AI prompts. Saved personal keys are encrypted; server keys remain private runtime configuration. Plain transaction references, emails and job history still require restricted database and backup access.
