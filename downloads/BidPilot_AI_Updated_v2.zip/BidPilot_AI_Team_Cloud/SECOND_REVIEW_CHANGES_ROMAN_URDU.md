# Updated v2 — kya theek hua?

29 October 2026 ko doosra review mukammal hua. Yeh ZIP pehle wali reviewed ZIP ki updated replacement hai.

- Logout/account switch ke baad puranay admin/customer ka data screen par rehne ka bug fix. Doosray browser tab mein account change ho to bhi purana data clear hota hai.
- Successful API test ke baad purana failure cooldown clear hota hai. Adhura AI jawab automatic bid mein use nahi hota.
- AI proposal bante waqt settings pause ho sakti hain; pause, expired subscription ya changed connection par bid request rukti hai.
- Missing currency/type, own project aur puranay unverified job records par live bid block hoti hai; rescan karein.
- Short skills, matching/risk filters, price rounding, chat delivery status aur private database permissions fix kiye.
- Healthcheck custom port aur database outage ko sahi handle karta hai.

**Verification:** 186 tests aur 12 subtests pass (latest startup/login/diagnostic patch); 13 Chromium desktop/mobile flows; Docker aur actual PostgreSQL checks pass. Kisi asli account par bid ya chat message nahi bheja gaya.

Packages $10 Starter aur $40 Pro hain; owner samait do founder slots free hain. Payment approval manual verification se hoti hai.

Ubuntu commands README_ROMAN_URDU.md mein hain. Existing installation update karne se pehle database aur matching private .env ka backup lein, old worker band karein, phir isolated copy par migration test karein. Purani FERNET_KEY preserve karein.

Live OpenAI/Gemini keys, Freelancer sandbox bid aur aapke domain ke HTTPS/payment settlement tests ab bhi aapke server par karne hain. Shared chat keys revoke karke fresh keys privately save karein. Koi app zero bugs ya hacker-proof guarantee nahi de sakti.

Latest patch mein localhost/127.0.0.1 local login403 fix, readable JSON errors, saved-only API tests aur Gemini404 available-model discovery shamil hain. OpenAI401 actual credential rejection hai; valid fresh secret key app mein save karni hogi. Production origin policy strict rehti hai.

Startup patch: optional second-founder email existing paid account se match ho to app ab band nahi hoti. Passwords, paid plan aur saved tokens preserve rehte hain; founder access sirf Admin se assign hota hai. Free seats ki concurrent assignment lock aur test-mode dotenv isolation bhi verify ki gayi.

Provider diagnostic patch: Gemini model listed hone par bhi404 ho to ab model change ka andaza nahi lagaya jata. Safe Provider code/status/reason aur body-format dikhte hain. Root cause code se confirm hoga; OpenAI401 par rejected saved key ko replace/verify karna zaroori hai.
